package com.example.userscrm

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.userscrm.Adapters.ClientAdapter
import com.example.userscrm.Data.Models.Client
import java.util.Date

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var clientAdapter: ClientAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.rvClients)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val clients = mutableListOf(
            Client(1, "Ivanov", "Ivan", "+380501234567", Date()),
            Client(2, "Petrov", "Petr", "+380501234568", Date()),
            Client(3, "Sidorov", "Sidr", "+380501234569", Date())
        )

        clientAdapter = ClientAdapter(this, clients)
        recyclerView.adapter = clientAdapter
    }
}
